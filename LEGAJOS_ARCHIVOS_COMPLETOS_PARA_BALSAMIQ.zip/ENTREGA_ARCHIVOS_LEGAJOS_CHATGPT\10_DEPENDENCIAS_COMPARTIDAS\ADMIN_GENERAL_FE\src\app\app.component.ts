import { Component } from '@angular/core';
import { EnvironmentService } from './core/services/environment.service';

import { RouterOutlet } from '@angular/router';

@Component({
    selector: 'app-root',
    imports: [RouterOutlet],
    templateUrl: './app.component.html',
    styleUrl: './app.component.scss'
})
export class AppComponent  {
  constructor(private environmentService: EnvironmentService) {
    this.environmentService.logEnvironmentInfo();
  }

  title = 'front-new';
}

import { Routes } from '@angular/router';
import { LoginFormComponent } from './auth/components/login-form/login-form.component';
import { NavComponent } from './admin/components/nav/nav.component';
import { authAdminPersonGuard } from './admin/guards/auth-admin-person.guard';
import { LegajoPersonalComponent } from './app-admin/components/legajo-personal/legajo-personal.component';
import { environment } from '@environments/environment';

const previewRoutes: Routes = environment.production ? [] : [
    {
        path: 'preview-legajos',
        component: LegajoPersonalComponent
    },
    {
        path: 'preview-mi-legajo',
        component: LegajoPersonalComponent
    },
    {
        path: 'preview-legajo-personal',
        redirectTo: 'preview-mi-legajo'
    }
];

export const routes: Routes = [
    ...previewRoutes,
    {
        path: '',
        component: LoginFormComponent
    },
    {
      path: '', // Cambiado de 'dashboard' a '' para rutas planas
      canActivate: [authAdminPersonGuard],
      component: NavComponent,
      children: [
          {
              path: '',
              loadChildren: () => import('./app-admin/app-admin.routes').then((m) => m.routes),
          }
      ]
    }
];

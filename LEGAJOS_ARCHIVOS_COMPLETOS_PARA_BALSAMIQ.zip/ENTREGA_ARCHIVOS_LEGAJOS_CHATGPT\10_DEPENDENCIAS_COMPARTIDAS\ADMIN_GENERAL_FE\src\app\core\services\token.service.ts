import { Injectable } from '@angular/core';
import { getCookie, setCookie, removeCookie } from 'typescript-cookie';

@Injectable({
  providedIn: 'root'
})
export class TokenService {

  constructor() { }

  saveToken(value: string) {
    setCookie('value-token', value, { expires: 1, path: '/'});
  }

  saveTokenApp(value: string, idApp: string) {
    let nameToken = idApp;
    setCookie(nameToken, value, { expires: 1, path: '/' });
  }

  getToken() {
    const value = getCookie('value-token');
    return value;
  }

  getTokenApp(idApp: string | null ) {
    let nameToken = idApp;
    const value = getCookie(nameToken ?? '');
    return value;
  }
  getRefreshTokenApp() {
    const value = getCookie('value-refreshToken');
    return value;
  }

  removeTokenListApp() {
    removeCookie('value-token');
  }

  removeTokenApp(idApp: string) {
    removeCookie(idApp);
  }
}

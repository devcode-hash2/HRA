import { CommonModule } from '@angular/common';
import { Component, HostListener, inject, OnInit, Renderer2 } from '@angular/core';
import { DomSanitizer, Title } from '@angular/platform-browser';
import { Router, RouterOutlet } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faBars, faArrowRightFromBracket, faAngleRight, faAngleDown, faXmark, faUsers, faCube, faLock, faUser, faAddressBook, faFloppyDisk, faEyeSlash, faEye, faUserShield } from '@fortawesome/free-solid-svg-icons';
import { MenuApp, Profile, ProfileApp, UpdateUser } from '@models/auth.model';
import { AuthService } from '@services/auth.service';
import { ToastrService } from 'ngx-toastr';
import { ModalFirstComponent } from './../../../admin/components/modal-first/modal-first.component';
import { AbstractControl, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { TokenService } from '@services/token.service';
import { interval, Subscription } from 'rxjs';
import { environment } from '@environments/environment';

/**
 * Componente de navegación lateral y superior.
 * Gestiona el menú, perfil de usuario, cierre de sesión y temporizador de sesión.
 */
@Component({
  selector: 'app-nav',
  imports: [FontAwesomeModule, CommonModule, RouterOutlet, ModalFirstComponent, ReactiveFormsModule],
  templateUrl: './nav.component.html',
  styleUrl: './nav.component.scss'
})
export class NavComponent implements OnInit {
  faBars = faBars;
  faArrowRightFromBracket = faArrowRightFromBracket;
  faAngleRight = faAngleRight;
  faAngleDown = faAngleDown;
  faXmark = faXmark;
  faLock = faLock;
  faUser = faUser;
  faAddressBook = faAddressBook;
  faFloppyDisk = faFloppyDisk;
  faEyeSlash = faEyeSlash;
  faEye = faEye;
  faUserShield = faUserShield;

  public toastrService = inject(ToastrService);
  private tokenService = inject(TokenService);
  private formBuilder = inject(FormBuilder);
  private renderer = inject(Renderer2);

  rutaActual: string = "";
  profileApp?: ProfileApp;
  profile?: Profile;
  imgperfil: any;
  loading = false;
  hidePassOld = true;
  hidePassNew = true;
  hidePassNewRep = true;
  msgConexionSession: string = "";

  menuData: MenuApp[] = [];
  menuExpanded: any[] = [];
  menuBoolExpanded: boolean = false;
  loadingIsOpen: boolean = false;
  timeLeft: number = 60;
  isRunning: boolean = false;
  idMenu: number = 0;

  listIconMenu: any[] = [];
  listColorIconMenu: string[] = [];
  titleDashboard: string = "AG - web master";

  stateNav: boolean = false;
  activeMenuUser: boolean = false;
  modalProfileOpen: boolean = false;
  modalChangePasswOpen: boolean = false;
  passwordDistinct: boolean = false;
  // userByToken?: UserByToken;
  modalConfirmSessionOpen: boolean = false;
  screenSizeLittle: boolean = false;
  clicInToggleNavBar: boolean = false;
  userIdFromToken?: string;

  private timerSubscription?: Subscription;

  constructor(
    private Titulo: Title,
    private router: Router,
    private authService: AuthService,
    private imgb64: DomSanitizer,
  ) {
    this.rutaActual = this.router.url;
  }

  formChangePassw = this.formBuilder.group({
    passwordOld: ['', [Validators.required]],
    passwordNew: ['', [Validators.required]],
    passwordNewRep: ['', [Validators.required]],
  });

  getFieldForm(campo: string, form: FormGroup): AbstractControl | null {
    return form.get(campo);
  }
  getInvalidForm(campo: string, form: FormGroup) {
    return this.getFieldForm(campo, form)?.touched && this.getFieldForm(campo, form)?.invalid;
  }

  // sesionApp = setTimeout(() => this.logoutApp(), this.authService.isTokenExpiredApp());
  sesionApp: any;

  /**
   * Inicializa el componente, carga perfil, menú y configura cierre automático de sesión.
   */
  ngOnInit(): void {
    this.checkScreenSize();
    this.loadingIsOpen = true;
    this.setupAutoLogout();
    this.authService.getProfileApp()
      .subscribe(data => {
        this.profileApp = data;
        this.userIdFromToken = data.idUser;
      })

    this.authService.getProfile(this.profileApp?.idUser ?? 0)
      .subscribe(data => {
        this.profile = data.value;

        if (this.profile.image != null) {
          this.imgperfil = this.imgb64.bypassSecurityTrustResourceUrl(`data:image/png;base64, ${this.profile.image}`);
        }
        if (this.profile.image == null) {
          if (this.profile.sex == 1) {
            this.imgperfil = 'assets/images/admin/photo-profile-male.jpg';
          }
          if (this.profile.sex == 2) {
            this.imgperfil = 'assets/images/admin/photo-profile-female.jpg';
          }
        }
      })

    this.authService.getMenuApp()
      .subscribe(data => {
        this.menuData = data.value;
        this.addLegajoPersonalMenuItem();

        for (let menu of this.menuData) {
          if (menu.icon == "faUsers") {
            this.listIconMenu.push(faUsers);
            this.listColorIconMenu.push("text-sky-600");
          }
          if (menu.icon == "faCube") {
            this.listIconMenu.push(faCube);
            this.listColorIconMenu.push("text-cyan-600");
          }
          if (menu.icon == "faUserShield") {
            this.listIconMenu.push(faUserShield);
            this.listColorIconMenu.push("text-orange-600");
          }
        }
        this.getTitleDashboard(this.menuData);
      });
    this.loadingIsOpen = false;
  }

  private addLegajoPersonalMenuItem(): void {
    const normalize = (value: string | undefined) =>
      (value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    const personalMenu = this.menuData.find(menu =>
      normalize(menu.nameMenu).includes('gestion de personal')
    );

    if (!personalMenu || personalMenu.sub_menu.some(item => item.ruta === 'legajos')) {
      return;
    }

    const legajoItem = {
      id_menu: -1,
      name: 'Legajos',
      ruta: 'legajos',
      titulo: 'Legajos',
      permiso: personalMenu.permiso
    };
    const personaIndex = personalMenu.sub_menu.findIndex(item =>
      normalize(item.name).includes('persona')
    );

    personalMenu.sub_menu.splice(personaIndex < 0 ? personalMenu.sub_menu.length : personaIndex + 1, 0, legajoItem);
  }

  /**
   * Configura el cierre automático de sesión según el tiempo del token.
   */
  setupAutoLogout(): void {
    this.loading = true;
    this.authService.getServerTime().subscribe(response => {
      this.loading = false;
      const serverTime = response.value;
      const tokenApp: string = this.tokenService.getTokenApp(environment.id_app) ?? '';
      const timeRemaining = this.isTokenExpiredApp(serverTime, tokenApp);

      if (timeRemaining > 0) {
        this.sesionApp = setTimeout(() => { this.openModalConfirmSession(); }, timeRemaining);
      } else {
        this.openModalConfirmSession();
      }
    });
  }

  /**
   * Calcula el tiempo restante antes de que expire el token.
   * @param serverTime Tiempo actual del servidor
   * @param tokenApp Token de la app
   * @returns Milisegundos restantes
   */
  isTokenExpiredApp(serverTime: number, tokenApp: string): number {
    const expiryApp = (JSON.parse(atob(tokenApp.split('.')[1]))).exp;
    return expiryApp * 1000 - serverTime * 1000;
  }

  /**
   * Inicia el temporizador de cuenta regresiva para la sesión.
   */
  startTimer() {
    this.isRunning = true; // Marca el cronómetro como activo
    this.timerSubscription = interval(1000).subscribe({
      next: () => {
        if (this.timeLeft > 0) {
          this.timeLeft--; // Decrementa el tiempo restante
        } else {
          this.timerSubscription?.unsubscribe(); // Detiene el cronómetro al llegar a 0
          this.isRunning = false; // Marca el cronómetro como inactivo
          this.logoutApp(); // Llama a la acción al finalizar
        }
      }
    });
  }

  /**
   * Abre el modal de confirmación de sesión.
   */
  openModalConfirmSession() {
    this.startTimer();
    this.modalConfirmSessionOpen = true;
  }

  /**
   * Renueva la sesión tras confirmación del usuario.
   */
  actionModalConfirmSession() {
    this.loading = true;
    this.msgConexionSession = "Estableciendo conexión";
    this.timerSubscription?.unsubscribe(); // Detiene cualquier cronómetro activo
    this.isRunning = false; // Marca el cronómetro como inactivo

    this.authService.renewSession().subscribe({
      next: () => {
        this.loading = false;
        this.modalConfirmSessionOpen = false;
        this.timeLeft = 60;
        this.setupAutoLogout();
        this.msgConexionSession = "";
      },
      error: (error) => {
        this.loading = false;
        this.msgConexionSession = "";
        // this.toastrService.error(error.error.value[0].message, 'App persona', { timeOut: 3200 });
        this.logoutApp();
      }
    })
  }

  /**
   * Cierra el modal de confirmación de sesión y cierra la sesión.
   */
  closeModalConfirmSession() {
    this.modalConfirmSessionOpen = false;
    this.logoutApp();
  }

  /**
   * Cambia el menú expandido o navega a la ruta seleccionada.
   */
  toggleMenu(idMenu: number, ruta: string): void {
    if (idMenu == this.idMenu) {
      this.menuBoolExpanded = !this.menuBoolExpanded;
    } else {
      this.menuBoolExpanded = true;
      this.idMenu = idMenu;
    }

    if (ruta != null) {
      this.rutaActual = ruta;
      this.router.navigate([ruta]);
    }
    this.getTitleDashboard(this.menuData);
  }

  btnSubmenu(direccion: string, tipo: string) {
    if (direccion != null && tipo == 'ruta') {
      this.rutaActual = direccion;
      this.router.navigate([direccion]);
    }
    this.getTitleDashboard(this.menuData);
  }

  isLegajosViewActive(view: 'hr' | 'employee'): boolean {
    const currentRoute = this.rutaActual.split('?')[0].replace(/^\/+|\/+$/g, '');
    return currentRoute === (view === 'hr' ? 'legajos' : 'mi-legajo');
  }

  isLegajosMenuItemActive(route: string): boolean {
    return route === 'legajos'
      ? this.isLegajosViewActive('hr') || this.isLegajosViewActive('employee')
      : route === this.rutaActual;
  }

  getTitleDashboard(listMenu: MenuApp[]) {
    for (let item of listMenu) {
      if (item.ruta == this.rutaActual || item.ruta + "/edit" == this.rutaActual || item.ruta + "/create" == this.rutaActual) {
        this.titleDashboard = item.titulo ?? "web master";
      }
      for (let childItem of item.sub_menu) {
        if (childItem.ruta == this.rutaActual || childItem.ruta + "/edit" == this.rutaActual || childItem.ruta + "/create" == this.rutaActual) {
          this.titleDashboard = childItem.titulo ?? "web master";
        }
      }
    }
    if (this.isLegajosViewActive('employee')) {
      this.titleDashboard = 'Mi legajo';
    }
    this.Titulo.setTitle('HRA - ' + this.titleDashboard);
  }

  logout() {
    this.authService.logoutApp(environment.id_app);
    window.location.href = environment.url_login;
  }

  toggleNavBar() {
    this.stateNav = !this.stateNav;
    this.clicInToggleNavBar = true;
  }

  /**
   * Cambia el estado del menú de usuario.
   */
  toggleMenuUser(event: MouseEvent) {
    event.stopPropagation();
    this.activeMenuUser = !this.activeMenuUser;
    if (window.innerWidth < 768) {
      this.stateNav = true;
      this.screenSizeLittle = true;
    }
  }

  /**
   * Cierra el menú de usuario si se hace clic fuera.
   */
  onClickOutside() {
    if (!this.activeMenuUser) return;
    if (this.activeMenuUser) this.activeMenuUser = !this.activeMenuUser;
  }

  /**
   * Cierra el menú lateral en pantallas pequeñas si se hace clic fuera.
   */
  onClickOutsideNavLeft() {
    if (this.screenSizeLittle && this.clicInToggleNavBar) {
      this.clicInToggleNavBar = false;
    } else {
      if (this.screenSizeLittle) this.stateNav = true;
    }
  }

  /**
   * Guarda el cambio de contraseña del usuario.
   */
  saveChangePassword() {
    if (this.formChangePassw.valid) {
      this.loading = true;
      this.formChangePassw?.disable();

      const buttons = document.querySelectorAll('.disabledxSave');
      buttons.forEach(button => { this.renderer.setAttribute(button, 'disabled', 'true'); });

      if (this.formChangePassw?.value.passwordNew != this.formChangePassw?.value.passwordNewRep) {
        this.passwordDistinct = true;
      }

      const changes: UpdateUser = {
        v_ID_USER: String(this.userIdFromToken),
        v_PREVIOUS_PASSWORD: String(this.formChangePassw?.value.passwordOld),
        v_NEW_PASSWORD: String(this.formChangePassw?.value.passwordNew),
        v_REPEAT_PASSWORD: String(this.formChangePassw?.value.passwordNewRep)
      }

      this.authService.updateUser(changes).subscribe({
        next: () => {
          this.loading = false;
          this.formChangePassw?.enable();
          buttons.forEach(button => { this.renderer.removeAttribute(button, 'disabled'); });

          this.modalChangePasswOpen = false;
          this.authService.logoutListApp();
          this.toastrService.success("Contraseña actualizada. Por favor inicie sesión nuevamente.", 'Acceso', { timeOut: 3200 });
          this.router.navigate(['./']);
        },
        error: (error) => {
          this.loading = false;
          this.formChangePassw?.enable();
          buttons.forEach(button => { this.renderer.removeAttribute(button, 'disabled'); });

          if (error.error.V_PASSWORD) {
            this.toastrService.error(error.error.V_PASSWORD[0], 'Acceso', { timeOut: 3200 });
          }
          if (error.error.V_NEW_PASSWORD) {
            this.toastrService.error(error.error.V_NEW_PASSWORD[0], 'Acceso', { timeOut: 3200 });
          }
          if (error.error.value) {
            this.toastrService.error(error.error.value[0].message, 'Acceso', { timeOut: 3200 });
          }
        }
      });
    } else {
      this.formChangePassw.markAllAsTouched();
    }
  }

  openModalProfile() {
    this.modalProfileOpen = true;
  }

  openModalChagePassw() {
    this.formChangePassw.reset();
    this.modalChangePasswOpen = true;

    var passwOld = document.querySelector('#passwordOld') as HTMLInputElement | null;
    if (passwOld) this.setFocus(passwOld);
  }

  // enviar el foco al input
  setFocus(inputElement: HTMLInputElement) {
    setTimeout(() => {
      inputElement.focus();
    }, 0);
  }

  /**
   * Cierra todos los modales abiertos.
   */
  closeModal() {
    this.modalProfileOpen = false;
    this.modalChangePasswOpen = false;
  }
  //cierre automatico
  // showMsgLogoutApp(){
  //   this.toastrService.warning('Sesión expirada.', 'Acceso', {
  //     timeOut: 3000,
  //   });
  //  }

  /**
   * Cierra la sesión y redirige al login.
   */
  logoutApp() {
    this.modalProfileOpen = false;
    // this.showMsgLogoutApp();
    this.authService.logoutApp(environment.id_app);
    window.location.href = environment.url_login;
  }

  /**
   * Verifica el tamaño de pantalla y ajusta el menú.
   */
  @HostListener('window:resize', ['$event'])
  checkScreenSize() {
    if (window.innerWidth < 768) {
      this.stateNav = true; // Ocultar el menú en pantallas pequeñas
      this.screenSizeLittle = true;
    } else {
      this.stateNav = false; // Mostrar el menú en pantallas grandes
      this.screenSizeLittle = false;
    }
  }
}

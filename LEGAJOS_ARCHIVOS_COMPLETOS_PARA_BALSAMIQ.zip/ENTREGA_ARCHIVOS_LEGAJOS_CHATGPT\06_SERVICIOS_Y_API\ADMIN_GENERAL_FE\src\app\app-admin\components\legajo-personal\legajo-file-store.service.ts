import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class LegajoFileStore {
  readonly files: Record<string, string> = {};
  readonly urls: Record<string, string> = {};
  readonly registeredAt: Record<string, Date> = {};
  readonly owners: Record<string, 'employee' | 'hr'> = {};
  readonly submittedSections: Record<string, boolean> = {};

  save(key: string, file: File, uploader: 'employee' | 'hr'): void {
    const previousUrl = this.urls[key];
    if (previousUrl) {
      URL.revokeObjectURL(previousUrl);
    }
    this.files[key] = file.name;
    this.urls[key] = URL.createObjectURL(file);
    this.registeredAt[key] = new Date();
    this.owners[key] = uploader;
    if (uploader === 'employee') {
      const [employeeId, sectionId] = key.split('-');
      delete this.submittedSections[`${employeeId}-${sectionId}`];
    }
  }

  remove(key: string): void {
    const [employeeId, sectionId] = key.split('-');
    const wasEmployeeUpload = this.owners[key] === 'employee';
    delete this.files[key];
    delete this.registeredAt[key];
    delete this.owners[key];
    const url = this.urls[key];
    if (url) {
      URL.revokeObjectURL(url);
      delete this.urls[key];
    }
    if (wasEmployeeUpload) {
      delete this.submittedSections[`${employeeId}-${sectionId}`];
    }
  }
}

import { isPlatformBrowser } from '@angular/common';
import { Inject, Injectable, PLATFORM_ID } from '@angular/core';
import { Subject } from 'rxjs';

export interface LegajoPersonData {
  fullName: string;
  dni: string;
  phone: string;
  email: string;
  address: string;
}

interface PersonalDataUpdate {
  employeeId: number;
  personalData: LegajoPersonData;
}

@Injectable({ providedIn: 'root' })
export class LegajoPersonalDataStore {
  private static readonly storagePrefix = 'hrayacucho-legajo-personal-data-';
  private readonly updates = new Subject<PersonalDataUpdate>();
  private readonly isBrowser: boolean;
  readonly updates$ = this.updates.asObservable();

  constructor(@Inject(PLATFORM_ID) platformId: object) {
    this.isBrowser = isPlatformBrowser(platformId);
    if (this.isBrowser) {
      window.addEventListener('storage', event => {
        const employeeId = this.employeeIdFromStorageKey(event.key);
        if (employeeId === undefined || !event.newValue) {
          return;
        }

        this.updates.next({
          employeeId,
          personalData: this.parsePersonalData(event.newValue)
        });
      });
    }
  }

  load(employeeId: number, fallback: LegajoPersonData): LegajoPersonData {
    if (!this.isBrowser) {
      return { ...fallback };
    }

    const storedData = window.localStorage.getItem(this.storageKey(employeeId));
    return storedData ? this.parsePersonalData(storedData) : { ...fallback };
  }

  save(employeeId: number, personalData: LegajoPersonData): void {
    if (!this.isBrowser) {
      throw new Error('El guardado de datos personales solo está disponible en el navegador.');
    }
    window.localStorage.setItem(this.storageKey(employeeId), JSON.stringify(personalData));
    this.updates.next({ employeeId, personalData: { ...personalData } });
  }

  private storageKey(employeeId: number): string {
    return `${LegajoPersonalDataStore.storagePrefix}${employeeId}`;
  }

  private employeeIdFromStorageKey(key: string | null): number | undefined {
    if (!key?.startsWith(LegajoPersonalDataStore.storagePrefix)) {
      return undefined;
    }

    const employeeId = Number(key.slice(LegajoPersonalDataStore.storagePrefix.length));
    return Number.isInteger(employeeId) && employeeId > 0 ? employeeId : undefined;
  }

  private parsePersonalData(value: string): LegajoPersonData {
    const parsed: unknown = JSON.parse(value);
    if (
      typeof parsed !== 'object' ||
      parsed === null ||
      !('fullName' in parsed) ||
      !('dni' in parsed) ||
      !('phone' in parsed) ||
      !('email' in parsed) ||
      !('address' in parsed) ||
      typeof parsed.fullName !== 'string' ||
      typeof parsed.dni !== 'string' ||
      typeof parsed.phone !== 'string' ||
      typeof parsed.email !== 'string' ||
      typeof parsed.address !== 'string'
    ) {
      throw new Error('Los datos personales guardados no tienen un formato válido.');
    }

    return {
      fullName: parsed.fullName,
      dni: parsed.dni,
      phone: parsed.phone,
      email: parsed.email,
      address: parsed.address
    };
  }
}

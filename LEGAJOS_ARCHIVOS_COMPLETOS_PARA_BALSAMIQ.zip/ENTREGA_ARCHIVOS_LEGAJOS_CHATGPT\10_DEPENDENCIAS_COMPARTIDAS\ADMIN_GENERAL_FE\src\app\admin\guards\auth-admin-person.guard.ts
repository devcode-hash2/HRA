import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { environment } from '@environments/environment';
import { TokenService } from '@services/token.service';

export const authAdminPersonGuard: CanActivateFn = (route, state) => {
  const tokenService = inject(TokenService);
    
  let tokenApp = tokenService.getTokenApp(environment.id_app) ?? "";
  let numberApp = sessionStorage.getItem('appNumber') ?? "";
  

  if (tokenApp == "" || numberApp == "") {
    window.location.href = environment.url_login;
    return false;
  }
  return true;
};
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { LegajoFileStore } from './legajo-file-store.service';
import { LegajoPersonData, LegajoPersonalDataStore } from './legajo-personal-data-store.service';
import {
  faAddressBook,
  faAddressCard,
  faArrowsRotate,
  faAward,
  faBriefcase,
  faChartLine,
  faCoins,
  faFileLines,
  faFileSignature,
  faFolderOpen,
  faGraduationCap,
  faHeartPulse,
  faPeopleGroup,
  faRightFromBracket
} from '@fortawesome/free-solid-svg-icons';

interface LegajoSection {
  id: number;
  title: string;
  description: string;
  iconPath: string;
  iconWidth: number;
  iconHeight: number;
  documents: string[];
  subsections?: { index: number; title: string }[];
  uploadPermissions?: {
    employee: number[];
    hr: number[];
  };
}

type PersonData = LegajoPersonData;

interface LegajoEmployee {
  id: number;
  status: 'Activo';
  personalData: PersonData;
}

const iconPath = (path: string | string[]): string => Array.isArray(path) ? path.join(' ') : path;

const LEGAJO_SECTIONS: LegajoSection[] = [
  {
    id: 1,
    title: 'Información personal y familiar',
    description: 'Datos personales y familiares del/de la servidor/a civil.',
    iconPath: iconPath(faAddressCard.icon[4]),
    iconWidth: faAddressCard.icon[0],
    iconHeight: faAddressCard.icon[1],
    documents: [
      'Copia del Documento Nacional de Identidad (DNI), título de nacionalidad, certificado de nacionalidad por matrimonio o visa de residencia.',
      'Copia del DNI del/de la cónyuge o concubino/a.',
      'Copia del DNI de los/las hijos/as menores de edad.',
      'Certificado de discapacidad del/de la servidor/a o de sus hijos/as, emitido por CONADIS, de corresponder.',
      'Declaración jurada o certificado de antecedentes penales.',
      'Declaración jurada o certificado de antecedentes policiales.',
      'Declaración jurada de bienes y rentas, de corresponder a funcionarios.',
      'Declaración jurada de no tener impedimentos conforme a la Ley N.° 31419.',
      'Copia de partida de matrimonio o constancia de concubinato (unión de hecho).',
      'Declaración jurada de impedimentos e inhabilitaciones (RNSSC, REDJUM, entre otros).'
    ]
  },
  {
    id: 2,
    title: 'Incorporación',
    description: 'Selección, vinculación, inducción y período de prueba.',
    iconPath: iconPath(faFileSignature.icon[4]),
    iconWidth: faFileSignature.icon[0],
    iconHeight: faFileSignature.icon[1],
    subsections: [
      { index: 0, title: '2.1. Documentación del proceso de selección (solo RR. HH.)' },
      { index: 2, title: '2.2. Documentación de formalización del vínculo' },
      { index: 7, title: '2.3. Documentación de la inducción del personal (solo RR. HH.)' },
      { index: 12, title: '2.4. Documentación del período de prueba' }
    ],
    documents: [
      'Resultado final del proceso de selección donde el/la servidor/a resultó ganador/a.',
      'Informe de RR. HH. que verifique el cumplimiento de los requisitos del puesto.',
      'Resolución administrativa de designación.',
      'Resolución administrativa de renovación.',
      'Resolución administrativa del servicio civil de carrera.',
      'Contrato.',
      'Adenda.',
      'Registro de inducción general y específica (solo RR. HH.).',
      'Cargo de entrega de perfil del puesto y funciones (solo RR. HH.).',
      'Cargo de entrega del Reglamento Interno de Servidores Civiles (solo RR. HH.).',
      'Cargo de entrega del código de conducta y ética (solo RR. HH.).',
      'Otros documentos de inducción (solo RR. HH.).',
      'Evaluación y resultados del período de prueba.'
    ],
    uploadPermissions: {
      employee: [2, 3, 4, 5, 6, 12],
      hr: [0, 1, 7, 8, 9, 10, 11]
    }
  },
  {
    id: 3,
    title: 'Formación académica y capacitación',
    description: 'Estudios, grados, colegiatura, habilitación y capacitación.',
    iconPath: iconPath(faGraduationCap.icon[4]),
    iconWidth: faGraduationCap.icon[0],
    iconHeight: faGraduationCap.icon[1],
    documents: [
      'Copia del certificado oficial de estudios básicos, si fue requerido para el puesto.',
      'Copia de títulos o grados de estudios superiores técnicos o universitarios.',
      'Copia de colegiatura y habilitación profesional, de corresponder.',
      'Copia de certificados o diplomas de posgrado, diplomados o especialización.',
      'Copia de diploma de grado académico de maestría y/o doctorado, de corresponder.',
      'Certificados, constancias o diplomas de cursos y programas de capacitación.',
      'Constancias de participación en congresos, convenciones, seminarios, talleres y similares.',
      'Otros documentos relacionados a la formación académica y capacitación.'
    ]
  },
  {
    id: 4,
    title: 'Experiencia laboral',
    description: 'Experiencia presentada durante el proceso de selección.',
    iconPath: iconPath(faBriefcase.icon[4]),
    iconWidth: faBriefcase.icon[0],
    iconHeight: faBriefcase.icon[1],
    documents: [
      'Certificados o constancias de trabajo que acrediten tiempo de servicio público o privado.',
      'Resoluciones, memorándums u otros documentos que acrediten las funciones desempeñadas.'
    ]
  },
  {
    id: 5,
    title: 'Movimientos del personal',
    description: 'Asistencia, permanencia, permisos, vacaciones, suspensiones y licencias.',
    iconPath: iconPath(faArrowsRotate.icon[4]),
    iconWidth: faArrowsRotate.icon[0],
    iconHeight: faArrowsRotate.icon[1],
    documents: [
      'Documento que aprueba la licencia o permiso solicitado.',
      'Documento que sustenta el goce vacacional.',
      'Documento que sustenta el adelanto o postergación de vacaciones.',
      'Rol de vacaciones.',
      'Licencias otorgadas: maternidad, paternidad, lactancia, adopción, familiares graves, comité SST, asistencia médica, bombero voluntario u otras.'
    ],
    uploadPermissions: {
      employee: [0, 1, 2, 3, 4],
      hr: [0, 1, 2, 3, 4]
    }
  },
  {
    id: 6,
    title: 'Compensaciones',
    description: 'Compensaciones económicas y no económicas y aportes del empleador.',
    iconPath: iconPath(faCoins.icon[4]),
    iconWidth: faCoins.icon[0],
    iconHeight: faCoins.icon[1],
    documents: [
      'Documento de reconocimiento de tiempo de servicios.',
      'Documentación referente al pago de compensaciones económicas y no económicas.',
      'Certificado de retención de quinta o cuarta categoría, de corresponder.',
      'Liquidación de beneficios sociales.'
    ]
  },
  {
    id: 7,
    title: 'Evaluación de desempeño, progresión en la carrera y desplazamiento',
    description: 'Gestión del rendimiento, progresión en la carrera y desplazamientos.',
    iconPath: iconPath(faChartLine.icon[4]),
    iconWidth: faChartLine.icon[0],
    iconHeight: faChartLine.icon[1],
    subsections: [
      { index: 0, title: '7.1. Evaluación de desempeño (solo RR. HH.)' },
      { index: 2, title: '7.2. Documentación de progresión en la carrera' },
      { index: 3, title: '7.3. Documentación de desplazamiento' }
    ],
    documents: [
      'Formatos de gestión del rendimiento: factores, evidencias, seguimiento y notificación de evaluación.',
      'Actas de retroalimentación de resultados de desempeño y plan de mejora.',
      'Resolución de progresión en la carrera.',
      'Designación.',
      'Rotación.',
      'Destaque, encargo de puestos o de funciones y otros desplazamientos.'
    ],
    uploadPermissions: {
      employee: [2, 3, 4, 5],
      hr: [0, 1]
    }
  },
  {
    id: 8,
    title: 'Reconocimientos y sanciones disciplinarias',
    description: 'Reconocimientos por mérito, procedimientos disciplinarios y documentación del RNSSC.',
    iconPath: iconPath(faAward.icon[4]),
    iconWidth: faAward.icon[0],
    iconHeight: faAward.icon[1],
    subsections: [
      { index: 0, title: '8.1. Reconocimientos' },
      { index: 3, title: '8.2. Sanciones disciplinarias (solo RR. HH.)' }
    ],
    documents: [
      'Cartas, oficios, memorandos, resoluciones o diplomas de reconocimiento por desempeño.',
      'Certificados o constancias de reconocimiento excepcional por labor docente.',
      'Certificados o constancias de reconocimiento por tiempo de servicio.',
      'Documentos que formalizan y comunican sanciones de amonestación escrita, suspensión o destitución (solo RR. HH.).',
      'Documentos que declaran fundados, infundados o improcedentes los recursos impugnatorios relativos a sanciones (solo RR. HH.).'
    ],
    uploadPermissions: {
      employee: [0, 1, 2],
      hr: [3, 4]
    }
  },
  {
    id: 9,
    title: 'Relaciones laborales individuales y colectivas',
    description: 'Controversias laborales y afiliación sindical.',
    iconPath: iconPath(faPeopleGroup.icon[4]),
    iconWidth: faPeopleGroup.icon[0],
    iconHeight: faPeopleGroup.icon[1],
    documents: [
      'Documentación relacionada a controversias individuales.',
      'Documentación relacionada a controversias colectivas.',
      'Resolución, acta o documento que indique afiliación al sindicato.'
    ]
  },
  {
    id: 10,
    title: 'Seguridad y salud en el trabajo (SST) y bienestar social',
    description: 'SST, incidentes, seguros, subsidios, descansos médicos y EPS.',
    iconPath: iconPath(faHeartPulse.icon[4]),
    iconWidth: faHeartPulse.icon[0],
    iconHeight: faHeartPulse.icon[1],
    subsections: [
      { index: 0, title: '10.1. Seguridad y salud en el trabajo (SST) (solo RR. HH.)' },
      { index: 3, title: '10.2. Bienestar social (solo RR. HH.)' }
    ],
    documents: [
      'Cargo de entrega del Reglamento de Seguridad y Salud en el Trabajo.',
      'Registro de entrenamiento y simulacros de emergencia.',
      'Lista de asistencia de capacitaciones brindadas por la entidad.',
      'Trámites y gestiones de seguro.',
      'Trámites y gestiones de subsidios.',
      'Descansos médicos.',
      'Afiliaciones a Entidades Prestadoras de Salud (EPS).'
    ],
    uploadPermissions: {
      employee: [],
      hr: [0, 1, 2, 3, 4, 5, 6]
    }
  },
  {
    id: 11,
    title: 'Finalización del vínculo laboral',
    description: 'Documentación del proceso de finalización del vínculo con la entidad.',
    iconPath: iconPath(faRightFromBracket.icon[4]),
    iconWidth: faRightFromBracket.icon[0],
    iconHeight: faRightFromBracket.icon[1],
    documents: [
      'Resolución de término de designación.',
      'Resolución de término del servicio civil de carrera.',
      'Memorando de término de vínculo del servicio civil.',
      'Informe de gestión.',
      'Entrega de cargo o puesto.',
      'Liquidación de beneficios sociales y/o pensión.',
      'Carta de no renovación de contrato a plazo determinado (Decreto Legislativo N.° 1057).'
    ],
    uploadPermissions: {
      employee: [],
      hr: [0, 1, 2, 3, 4, 5, 6]
    }
  },
  {
    id: 12,
    title: 'Otros documentos',
    description: 'Documentos relevantes que no corresponden a las secciones anteriores.',
    iconPath: iconPath(faFolderOpen.icon[4]),
    iconWidth: faFolderOpen.icon[0],
    iconHeight: faFolderOpen.icon[1],
    documents: [
      'Otros documentos generados por procesos de gestión de recursos humanos o relevantes para la trayectoria laboral.'
    ],
    uploadPermissions: {
      employee: [0],
      hr: [0]
    }
  },
//{
//   id: 13,
//    title: 'Currículum Vitae (CV)',
//    description: 'Adjunta tu currículum vitae actualizado en formato PDF o Word.',
//    iconPath: iconPath(faFileLines.icon[4]),
//    iconWidth: faFileLines.icon[0],
//    iconHeight: faFileLines.icon[1],
//    documents: ['Currículum Vitae (CV)']
//  }
//
];

@Component({
  selector: 'app-legajo-personal',
  imports: [CommonModule, FormsModule],
  templateUrl: './legajo-personal.component.html'
})
export class LegajoPersonalComponent {
  readonly sections = LEGAJO_SECTIONS;
  readonly personaIconPath = iconPath(faAddressBook.icon[4]);
  readonly personaIconWidth = faAddressBook.icon[0];
  readonly personaIconHeight = faAddressBook.icon[1];
  readonly demoEmployees: LegajoEmployee[] = [

  {
    id: 1,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 01',
      dni: 'DEMO-01',
      phone: 'TEL-DEMO-01',
      email: 'demo01@example.invalid',
      address: 'Dirección ficticia 01'
    }
  },
  {
    id: 2,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 02',
      dni: 'DEMO-02',
      phone: 'TEL-DEMO-02',
      email: 'demo02@example.invalid',
      address: 'Dirección ficticia 02'
    }
  },
  {
    id: 3,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 03',
      dni: 'DEMO-03',
      phone: 'TEL-DEMO-03',
      email: 'demo03@example.invalid',
      address: 'Dirección ficticia 03'
    }
  },
  {
    id: 4,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 04',
      dni: 'DEMO-04',
      phone: 'TEL-DEMO-04',
      email: 'demo04@example.invalid',
      address: 'Dirección ficticia 04'
    }
  },
  {
    id: 5,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 05',
      dni: 'DEMO-05',
      phone: 'TEL-DEMO-05',
      email: 'demo05@example.invalid',
      address: 'Dirección ficticia 05'
    }
  },
  {
    id: 6,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 06',
      dni: 'DEMO-06',
      phone: 'TEL-DEMO-06',
      email: 'demo06@example.invalid',
      address: 'Dirección ficticia 06'
    }
  },
  {
    id: 7,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 07',
      dni: 'DEMO-07',
      phone: 'TEL-DEMO-07',
      email: 'demo07@example.invalid',
      address: 'Dirección ficticia 07'
    }
  },
  {
    id: 8,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 08',
      dni: 'DEMO-08',
      phone: 'TEL-DEMO-08',
      email: 'demo08@example.invalid',
      address: 'Dirección ficticia 08'
    }
  },
  {
    id: 9,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 09',
      dni: 'DEMO-09',
      phone: 'TEL-DEMO-09',
      email: 'demo09@example.invalid',
      address: 'Dirección ficticia 09'
    }
  },
  {
    id: 10,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 10',
      dni: 'DEMO-10',
      phone: 'TEL-DEMO-10',
      email: 'demo10@example.invalid',
      address: 'Dirección ficticia 10'
    }
  },
  {
    id: 11,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 11',
      dni: 'DEMO-11',
      phone: 'TEL-DEMO-11',
      email: 'demo11@example.invalid',
      address: 'Dirección ficticia 11'
    }
  },
  {
    id: 12,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 12',
      dni: 'DEMO-12',
      phone: 'TEL-DEMO-12',
      email: 'demo12@example.invalid',
      address: 'Dirección ficticia 12'
    }
  },
  {
    id: 13,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 13',
      dni: 'DEMO-13',
      phone: 'TEL-DEMO-13',
      email: 'demo13@example.invalid',
      address: 'Dirección ficticia 13'
    }
  },
  {
    id: 14,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 14',
      dni: 'DEMO-14',
      phone: 'TEL-DEMO-14',
      email: 'demo14@example.invalid',
      address: 'Dirección ficticia 14'
    }
  },
  {
    id: 15,
    status: 'Activo',
    personalData: {
      fullName: 'Persona de demostración 15',
      dni: 'DEMO-15',
      phone: 'TEL-DEMO-15',
      email: 'demo15@example.invalid',
      address: 'Dirección ficticia 15'
    }
  }
  
];

  selectedSection = 1;
  selectedEmployee = this.demoEmployees[0];
  sidebarCollapsed = false;
  personalDataDraft: PersonData = { ...this.demoEmployees[0].personalData };
  personalDataMessage = '';
  showingSectionDocuments = false;
  searchTerm = '';
  activeTab: 'documents' | 'personal' = 'documents';
  declarationAnswers: Record<string, string> = {};
  uploadMessage = '';

  constructor(
    private readonly router: Router,
    private readonly fileStore: LegajoFileStore,
    private readonly personalDataStore: LegajoPersonalDataStore
  ) {
    this.demoEmployees.forEach(employee => {
      employee.personalData = this.personalDataStore.load(employee.id, employee.personalData);
    });

    this.personalDataStore.updates$
      .pipe(takeUntilDestroyed())
      .subscribe(({ employeeId, personalData }) => {
        const employee = this.demoEmployees.find(item => item.id === employeeId);
        if (employee) {
          Object.assign(employee.personalData, personalData);
        }
      });
  }

  get employeeFiles(): Record<string, string> {
    return this.fileStore.files;
  }

  get viewMode(): 'hr' | 'employee' {
    return this.router.url.includes('preview-legajos') || this.router.url.includes('/legajos') ? 'hr' : 'employee';
  }

  get isPreview(): boolean {
    return this.router.url.startsWith('/preview-');
  }

  get activeSection(): LegajoSection {
    return this.sections.find(section => section.id === this.selectedSection) ?? this.sections[0];
  }

  get filteredEmployees(): LegajoEmployee[] {
    const query = this.searchTerm.trim().toLocaleLowerCase();
    return this.demoEmployees.filter(employee =>
      employee.status === 'Activo' &&
      (!query ||
        employee.personalData.fullName.toLocaleLowerCase().includes(query) ||
        employee.personalData.dni.includes(query))
    );
  }

  get activeEmployee(): LegajoEmployee {
    return this.viewMode === 'hr' ? this.selectedEmployee : this.demoEmployees[0];
  }

  get completedDocuments(): number {
    return this.sections.reduce((total, section) => total + section.documents.filter((document, index) =>
      this.canUploadDocument(section.id, index, 'employee') &&
      !this.isDeclaration(document) &&
      Boolean(this.employeeFiles[this.sectionKey(section.id, index)])
    ).length, 0);
  }

  get totalDocuments(): number {
    return this.sections.reduce((total, section) =>
      total + section.documents.filter((_, index) =>
        this.canUploadDocument(section.id, index, 'employee') &&
        !this.isDeclaration(section.documents[index])
      ).length, 0);
  }

  sectionKey(sectionId: number, documentIndex: number): string {
    return `${this.activeEmployee.id}-${sectionId}-${documentIndex}`;
  }

  selectEmployee(employee: LegajoEmployee): void {
    this.selectedEmployee = employee;
    this.selectedSection = 1;
    this.showingSectionDocuments = false;
    this.activeTab = 'documents';
  }

  selectSection(sectionId: number): void {
    this.selectedSection = sectionId;
    this.showingSectionDocuments = true;
    this.activeTab = 'documents';
  }

  showSections(): void {
    this.showingSectionDocuments = false;
  }

  openPersonalDataTab(): void {
    this.personalDataDraft = { ...this.activeEmployee.personalData };
    this.personalDataMessage = '';
    this.activeTab = 'personal';
  }

  cancelPersonalDataChanges(): void {
    this.personalDataDraft = { ...this.activeEmployee.personalData };
    this.personalDataMessage = '';
  }

  savePersonalDataChanges(): void {
    try {
      this.personalDataStore.save(this.activeEmployee.id, this.personalDataDraft);
      Object.assign(this.activeEmployee.personalData, this.personalDataDraft);
      this.personalDataDraft = { ...this.activeEmployee.personalData };
      this.personalDataMessage = 'Los datos se guardaron y están disponibles para Recursos Humanos.';
    } catch (error) {
      console.error('No se pudieron guardar los datos personales.', error);
      this.personalDataMessage = 'No se pudieron guardar los datos. Intenta nuevamente.';
    }
  }

  sectionProgress(sectionId: number): string {
    const prefix = `${this.activeEmployee.id}-${sectionId}-`;
    const uploaded = Object.keys(this.employeeFiles).filter(key => key.startsWith(prefix)).length;
    return uploaded ? `${uploaded} de ${this.sections[sectionId - 1].documents.length} cargados` : 'Pendiente';
  }

  sectionStatus(sectionId: number): 'Pendiente' | 'En proceso' | 'Completado' {
    const section = this.sections[sectionId - 1];
    const employeeDocuments = section.documents
      .map((document, index) => ({ document, index }))
      .filter(item =>
        this.canUploadDocument(sectionId, item.index, 'employee') &&
        !this.isDeclaration(item.document)
      );
    const uploaded = employeeDocuments.filter(item =>
      Boolean(this.employeeFiles[this.sectionKey(sectionId, item.index)])
    ).length;
    const required = employeeDocuments.length;

    if (uploaded === 0) {
      return 'Pendiente';
    }

    return uploaded >= required ? 'Completado' : 'En proceso';
  }

  openView(view: 'hr' | 'employee'): void {
    const previewPrefix = this.isPreview ? '/preview-' : '/';
    const viewPath = view === 'hr' ? 'legajos' : 'mi-legajo';
    void this.router.navigateByUrl(`${previewPrefix}${viewPath}`);
  }

  statusForDocument(key: string): 'Registrado' | 'Pendiente' {
    return this.documentFileName(key) ? 'Registrado' : 'Pendiente';
  }

  documentFileName(key: string): string | undefined {
    if (this.viewMode === 'hr' && this.fileStore.owners[key] === 'employee') {
      const [employeeId, sectionId] = key.split('-');
      if (!this.fileStore.submittedSections[`${employeeId}-${sectionId}`]) {
        return undefined;
      }
    }
    return this.employeeFiles[key];
  }

  documentRegistrationDate(key: string): Date | undefined {
    return this.documentFileName(key) ? this.fileStore.registeredAt[key] : undefined;
  }

  canUploadDocument(sectionId: number, documentIndex: number, uploader: 'employee' | 'hr'): boolean {
    const section = this.sections.find(item => item.id === sectionId);
    if (!section) {
      return false;
    }
    return section.uploadPermissions
      ? section.uploadPermissions[uploader].includes(documentIndex)
      : uploader === 'employee';
  }

  isHrManagedDocument(sectionId: number, documentIndex: number): boolean {
    return this.canUploadDocument(sectionId, documentIndex, 'hr') &&
      !this.canUploadDocument(sectionId, documentIndex, 'employee');
  }

  uploadResponsibility(sectionId: number, documentIndex: number): string {
    const employeeCanUpload = this.canUploadDocument(sectionId, documentIndex, 'employee');
    const hrCanUpload = this.canUploadDocument(sectionId, documentIndex, 'hr');
    if (employeeCanUpload && hrCanUpload) {
      return 'Servidor/a y RR. HH.';
    }
    return hrCanUpload ? 'Solo RR. HH.' : 'Solo servidor/a';
  }

  isCurriculumVitae(document: string): boolean {
    return /curr[ií]culum vitae|\bCV\b/i.test(document);
  }

  documentFileUrl(key: string): string | undefined {
    if (!this.documentFileName(key)) {
      return undefined;
    }
    return this.fileStore.urls[key];
  }

  downloadFileName(key: string): string | undefined {
    return this.documentFileName(key);
  }

  isDeclaration(document: string): boolean {
    return /antecedentes penales|antecedentes policiales|Ley N\.° 31419|impedimentos e inhabilitaciones/i.test(document);
  }

  onDeclarationAnswerChange(sectionId: number, documentIndex: number, answer: string): void {
    if (answer !== 'Sí') {
      this.removeAttachment(this.sectionKey(sectionId, documentIndex));
    }
  }

  hasEmployeeDocuments(sectionId: number): boolean {
    const section = this.sections[sectionId - 1];
    return section.documents.some((_, index) =>
      this.canUploadDocument(sectionId, index, 'employee')
    );
  }

  hasEmployeeUpload(sectionId: number): boolean {
    const section = this.sections.find(item => item.id === sectionId);
    if (!section) {
      return false;
    }

    return section.documents.some((_, index) => {
      const key = this.sectionKey(sectionId, index);
      return this.canUploadDocument(sectionId, index, 'employee') &&
        this.fileStore.owners[key] === 'employee' &&
        Boolean(this.employeeFiles[key]);
    });
  }

  canRemoveEmployeeAttachment(sectionId: number, documentIndex: number): boolean {
    const key = this.sectionKey(sectionId, documentIndex);
    return this.viewMode === 'employee' &&
      this.fileStore.owners[key] === 'employee' &&
      Boolean(this.employeeFiles[key]);
  }

  canRemoveHrAttachment(sectionId: number, documentIndex: number): boolean {
    const key = this.sectionKey(sectionId, documentIndex);
    return this.viewMode === 'hr' &&
      this.fileStore.owners[key] === 'hr' &&
      Boolean(this.employeeFiles[key]);
  }

  isSectionSubmitted(sectionId: number): boolean {
    return Boolean(this.fileStore.submittedSections[`${this.activeEmployee.id}-${sectionId}`]);
  }

  submitSection(sectionId: number): void {
    if (!this.hasEmployeeUpload(sectionId)) {
      this.uploadMessage = 'Adjunta al menos un documento antes de enviarlo a Recursos Humanos.';
      return;
    }
    this.fileStore.submittedSections[`${this.activeEmployee.id}-${sectionId}`] = true;
    this.uploadMessage = 'La sección ahora está visible para Recursos Humanos.';
  }

  onFileSelected(event: Event, sectionId: number, documentIndex: number): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.item(0);
    const uploader = this.viewMode === 'hr' ? 'hr' : 'employee';
    const document = this.sections.find(section => section.id === sectionId)?.documents[documentIndex];
    if (file && document && this.canUploadDocument(sectionId, documentIndex, uploader) &&
        this.isFileAllowed(file, this.isCurriculumVitae(document))) {
      this.saveAttachment(this.sectionKey(sectionId, documentIndex), file);
    }
    input.value = '';
  }

  private isFileAllowed(file: File, curriculumVitaeOnly: boolean): boolean {
    const extension = file.name.split('.').pop()?.toLocaleLowerCase() ?? '';
    const allowedExtensions = curriculumVitaeOnly
      ? ['pdf', 'doc', 'docx']
      : ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];
    if (!allowedExtensions.includes(extension)) {
      this.uploadMessage = curriculumVitaeOnly
        ? 'Para el CV, selecciona un archivo PDF, DOC o DOCX.'
        : 'Formato no permitido. Selecciona un archivo PDF, JPG, PNG, DOC o DOCX.';
      return false;
    }

    if (file.size > 10 * 1024 * 1024) {
      this.uploadMessage = 'El archivo supera el tamaño máximo de 10 MB.';
      return false;
    }

    this.uploadMessage = '';
    return true;
  }

  private saveAttachment(key: string, file: File): void {
    const uploader = this.viewMode === 'hr' ? 'hr' : 'employee';
    this.fileStore.save(key, file, uploader);
  }

  removeAttachment(key: string): void {
    this.fileStore.remove(key);
  }
}

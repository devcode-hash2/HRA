import { Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AplicativoComponent } from './components/aplicativo/aplicativo.component';
import { UsuarioComponent } from './components/usuario/usuario.component';
import { RolComponent } from './components/rol/rol.component';
import { LegajoPersonalComponent } from './components/legajo-personal/legajo-personal.component';

export const routes: Routes = [
    {
        path: 'legajos',
        component: LegajoPersonalComponent
    },
    {
        path: 'mi-legajo',
        component: LegajoPersonalComponent
    },
    {
        path: 'apps',
        component: AplicativoComponent
    },
    {
        path: 'roles',
        component: RolComponent
    },
    {
        path: 'usuarios',
        component: UsuarioComponent
    },
    {
        path: 'home',
        component: DashboardComponent
    }
];
